import numpy as np

class SortTracker:
    def __init__(self):
        self.trackers = {}  # {id: box_dict}
        self.next_id = 0

    def iou(self, boxA, boxB):
        # boxA and boxB are lists [x1,y1,x2,y2]
        xA = max(boxA[0], boxB[0])
        yA = max(boxA[1], boxB[1])
        xB = min(boxA[2], boxB[2])
        yB = min(boxA[3], boxB[3])

        interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
        boxAArea = (boxA[2]-boxA[0]+1)*(boxA[3]-boxA[1]+1)
        boxBArea = (boxB[2]-boxB[0]+1)*(boxB[3]-boxB[1]+1)
        if boxAArea + boxBArea - interArea == 0:
            return 0
        iou = interArea / float(boxAArea + boxBArea - interArea)
        return iou

    def update(self, detections):
        updated = {}
        matched = set()

        # Match existing trackers
        for tid, tbox_dict in self.trackers.items():
            tbox = tbox_dict["box"]  # <-- FIX: extract box list
            best_iou = 0
            best_det = None
            for i, det in enumerate(detections):
                if i in matched:
                    continue
                score = self.iou(tbox, det)
                if score > best_iou:
                    best_iou = score
                    best_det = i
            if best_iou > 0.3:
                updated[tid] = {"box": detections[best_det]}
                matched.add(best_det)

        # Add unmatched detections as new trackers
        for i, det in enumerate(detections):
            if i not in matched:
                updated[self.next_id] = {"box": det}
                self.next_id += 1

        self.trackers = updated
        return updated
