from ultralytics import YOLO
import cv2
from sort import SortTracker

# Load YOLO model
model = YOLO("models/yolov8n.pt")

# Initialize SORT tracker
tracker = SortTracker()

# Video file
cap = cv2.VideoCapture("videos/vedio.mp4")  # your video file

if not cap.isOpened():
    print("Error: Could not open video file")
    exit()

# Setup VideoWriter to save output video
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS) or 20.0  # use video FPS if available
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter('output/results.mp4', fourcc, fps, (width, height))

print("Processing video... Press 'q' to quit early.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("End of video")
        break  # Stop if video ends

    # YOLO object detection
    results = model(frame)[0]

    detections = []
    for box in results.boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        detections.append([x1, y1, x2, y2])

    # Update tracker
    tracked = tracker.update(detections)

    # Draw boxes + IDs
    for tid, obj in tracked.items():
        x1, y1, x2, y2 = obj["box"]
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, f"ID {tid}", (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    # Save frame to results.mp4
    out.write(frame)

    # Display frame
    cv2.imshow("Object Detection + Tracking", frame)

    # Press 'q' to exit early
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print("Quitting early...")
        break

# Release resources
cap.release()
out.release()
cv2.destroyAllWindows()
print("Processing complete. Video saved to output/results.mp4")
