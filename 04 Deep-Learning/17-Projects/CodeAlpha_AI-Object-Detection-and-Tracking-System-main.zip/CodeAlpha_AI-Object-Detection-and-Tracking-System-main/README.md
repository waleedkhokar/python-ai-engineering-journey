# CodeAlpha_AI-Object-Detection-and-Tracking-System
This project performs real-time object detection and tracking using YOLOv8 and a SORT tracker. It processes video input from a webcam or file, draws bounding boxes with unique IDs, and saves the output as a video file. Ideal for monitoring, traffic analysis, or smart surveillance applications.
